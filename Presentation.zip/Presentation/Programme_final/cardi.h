#ifndef cardio_h  
#define cardio_h   

#include "Arduino.h" 
                            //Dans cette partie nous créons nos fonctions, ce qui nous permettra dans le fichier .cpp de les définirs.
void calcul();      
void affichagebpm();
void set();               

#endif
